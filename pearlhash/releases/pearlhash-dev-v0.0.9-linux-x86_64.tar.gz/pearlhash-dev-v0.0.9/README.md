# PearlHash v0.0.9 commitment-leaf correctness component

Independent keyed BLAKE3 chunk CV kernel, not a working miner.
141 synthetic 1024-byte chunks and an empty-launch case cover zero/FF data,
nonaligned launches, the 64-MiB and 8-GiB index boundaries, 32-bit counter carry
and the maximum u64 counter. These sparse boundary cases do NOT hash an entire
8-GiB matrix. CVs are chaining values, not standalone root digests.
Official BLAKE3 portable compression generates the pinned synthetic CV goldens;
they are not Pearl full-proof goldens. A two-chunk root golden also checks the
CV/root domain distinction. Ordinary CPU kernel-body comparisons and guards pass;
GPU execution remains pending until the rig runs this package.

From this directory:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/check_commitment_gpu.py

Source and binaries included. No toolchain installation, network connection,
service or clock changes. Previous nonce/math GPU tests need not be repeated.
No complete tree, pool share or efficiency claim. Full pool reconstruction is
still unresolved; leave the working miner in place.

Rebuild the CPU library and checker on a development host:

    g++ -std=c++17 -O3 -Wall -Wextra -Werror -shared -fPIC -fvisibility=hidden proof/blake3_cpu.cpp -o bin/libpearlhash.so
    g++ -std=c++17 -O3 -Wall -Wextra -Werror tests/chunk_kernel_cpu.cpp -o bin/pearl-chunk-cpu-check
    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/chunk-commitment-sm120.cubin chunk_commitment.cu

Library and CPU checker require Linux x86_64 libc/libstdc++; GPU runner uses
Python's standard library and the installed NVIDIA driver.

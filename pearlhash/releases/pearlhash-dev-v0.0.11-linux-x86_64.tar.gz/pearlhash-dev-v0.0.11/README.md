# PearlHash v0.0.11 local captured-share replay

Generic offline correctness tool. No pool connection, retransmission or custom
share. Private capture records, fingerprints and derived values are not bundled.
The user supplies a local context, request ID, candidate notify packet and
expected local SHA-256. This tool never uploads or resends those records.

Supported observed dense mode: enabled sb flag, empty sb_p, tail_mode=1,
rank 128 and explicit V3 replay. Signal fill is 64; sb is not a literal fill
byte. The final 16 A bytes use the independent worker/miner nonce mapping.
Unsupported modes reject; this is not a general deployed-version specification.

CPU code streams complete matrix commitments and sparse Merkle openings without
allocating a full matrix or complete CV tree. Inputs are bounded at 8 GiB.
CPU work may take several minutes alongside XMRig. The selected digest must
clear the supplied target, then the existing GPU checker compares noise/math
and the pinned official CPU verifier checks the independently built PlainProof.
The share target must be exactly representable as nBits; header bytes remain
unchanged. Results and their hashes are written only to the local output dir.

Development CPU roots match independent streaming BLAKE3 evidence; selected math
matches the separate C++ checker. Small sparse openings serialize exactly like
materialized CPU trees in 16 odd/even/tail cases, with corruption rejection and
native address/undefined sanitizer guards. New replay GPU/official-verifier
execution remains pending on the rig. Earlier synthetic V2/V3 GPU-to-proof
runs passed and do not need repeating. No working miner or performance claim.

From this directory, supply your LOCAL record selectors and fingerprint:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S -m tools.replay_pool_context --context /path/to/private-context.json --submit-id ID --notify-packet PACKET --expect-context-sha256 SHA256 --oracle /home/user/pearlhash-dev-v0.0.2/bin/pearl-cpu-oracle --gpu-check /home/user/pearlhash-dev-v0.0.5/bin/pearl-gpu-check --cubin /home/user/pearlhash-dev-v0.0.5/gpu/correctness-sm120.cubin --output-dir ./run

The project source, Linux CPU library and existing GPU math/verifier binaries
are distributed through GitHub. This package reuses the already installed math
checker and oracle; no toolchain install or old fixture rerun is needed.

Rebuild the CPU library on a development host:

    g++ -std=c++17 -O3 -Wall -Wextra -Werror -shared -fPIC -fvisibility=hidden proof/blake3_cpu.cpp -o bin/libpearlhash.so

Materialized trees remain capped at 64 MiB. Constant sparse openings support
at most 8388608 chunks, 4096 selected leaves and 65536 sibling nodes. Proof
parsing stays capped at 8 MiB. Parents, seeds, openings and verification run on
CPU. No service, clock, autostart or pool setting changes are performed.

# PearlHash v0.0.13 GPU noise-to-MMA component

This offline component generates both sides' uniform/permutation noise tables
and signed noised bytes on the GPU, then consumes those same device buffers
with the independent integer tensor-core matrix kernel. Supplied noise seeds,
selected row/column indices and signal bytes remain caller inputs. It does not
implement seed derivation, commitments, nonce search, targets or pool submission.

One keyed hash produces 32 uniform bytes or eight permutation pairs. Uniform
rows and the per-side permutation table can be reused across matrix tiles.
This replaces per-element repeated noise hashing in this component; no measured
speed or power improvement is claimed. No floating point or FP8 is introduced.

The runner compares every uniform byte, permutation pair and signed noised byte,
then every rank-boundary product, transcript word and digest, with independent
CPU calculations. All outputs have poison guards. Actual GPU-produced buffers
feed the MMA launch without uploading CPU noised matrices. Copying outputs back
for reference comparison is part of this correctness harness, not a benchmark.

The earlier standalone integer MMA path passed all five cases on the RTX 5060.
This combined native sm_120 build compiles; its GPU execution is pending.
CPU tests: 50 passed / two prior oracle/vector cases skipped. The actual noise
kernel bodies passed CPU differential/guard checks, including rank32/128/1024,
repeated indices, selected-index limits and padded tiles. Those CPU checks do
not execute GPU instructions. Official-generated V2/V3 noise and digests match.

Run with Python 3.10+ and NVIDIA driver; no CUDA compiler, Rust or pip required:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/check_noise_mma_gpu.py --fixture /path/to/local/PHGPU02.bin --report ./noise-mma-result.json

Three synthetic cases run first; the optional saved local PHGPU02 fixture is
read only. The runner uploads supplied seeds, indices and signal bytes, derives
noise on the GPU, then compares against that file's noised matrices and digest.
It makes no network connections or changes to services, clocks or autostart.
Nothing from the private fixture is bundled or uploaded. The existing miners
can remain running. This test cannot measure comparable throughput under load.

Bounds: 1..32 rows and columns, k<=65536, k divisible by a power-of-two rank
32..1024, signals in [-64,64], complete uniform row fits a u32 linear index.
Noised signed bytes fit [-127,127], and int32 accumulation cannot overflow.
Malformed fixtures fail before CUDA initialization. Any GPU mismatch stops;
there is no CPU fallback pretending to be a GPU result. Completion report is
written only after all selected cases pass and refuses an existing report.

Rebuild cubin on the development host using the included sources:

    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/noise-mma-sm120.cubin noise_mma.cu

The CPU library source is proof/blake3_cpu.cpp; rebuild with:

    g++ -std=c++17 -O3 -shared -fPIC proof/blake3_cpu.cpp -o bin/libpearlhash.so

The library bytes included here are unchanged from v0.0.11. BUILD.json records
source hashes and compilation scope. ISC license; no vendor miner runtime.

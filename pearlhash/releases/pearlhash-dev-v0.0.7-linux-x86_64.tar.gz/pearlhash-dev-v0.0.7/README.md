# PearlHash v0.0.7 protocol development package

Linux x86_64 binaries and native NVIDIA sm_120 correctness kernels, with source.
This is a development package, not a working pool miner. No custom pool share
has been accepted and no performance or power improvement is demonstrated.

New: independent notify/header conversion, chronological TCP/frame decoding,
and a passive collector retaining preceding notify candidates + an accepted
existing-miner submit/reply. Matrix reconstruction, header association and pool
target semantics still need validation. No share is transmitted by these tools.

Rebuilt: bin/pearl-gpu-check, bin/libpearlhash.so and
GPU correctness-sm120.cubin. The cubin and hash library are byte-identical to
v0.0.5. The rebuilt CPU checker passes all twelve existing math input cases.
There is no new GPU run for this rebuild; previous v0.0.3/v0.0.4 and v0.0.5
GPU-to-proof runs passed on the user's RTX 5060. Completed rig tests need not
be repeated for this protocol work. BUILD.json records exact source hashes.

## Next required rig evidence

Leave existing miners running. From this extracted directory:

    python3 -S tools/capture_share_context.py --captures /home/user/pearlhash-dev/captures

This watches the existing connection for up to 600 seconds/1,024 packets,
stopping early when preceding notifications and an accepted submit/reply have
been observed. Only its own capture process group is stopped. It sends no
messages and changes no services or clocks. It requires the already installed
tcpdump and sudo. It prints selected messages; the full PCAP/JSON stay local.
Preceding notification(s) are candidates; timing alone does not establish which
header belongs to the submission. Notify field 3 is not equated to worker_nonce.

## Other included components

The prior synthetic offline end-to-end proof runner is retained with its source:

    python3 -S -m tools.offline_end_to_end --oracle /home/user/pearlhash-dev-v0.0.2/bin/pearl-cpu-oracle --output-dir ./new-run

It requires the existing official oracle; this package does not rebuild or
replace it. No CUDA/Rust compiler or Python package installation on the rig.
There is no fee, hidden connection, WildRig wrapper or vendor runtime dependency.
All independent project source is ISC licensed; see LICENSE. The official
verifier remains an external pinned correctness oracle.

22 protocol/header/context CPU tests can be run with:

    PYTHONPATH=.:tests python3 -S -m unittest test_pool_capture test_pool_probe test_decode_pool_capture test_pool_job test_share_context

SHA256SUMS covers every package member except itself. No private capture,
research vendor binary, toolchain or diagnostic transcript is included.

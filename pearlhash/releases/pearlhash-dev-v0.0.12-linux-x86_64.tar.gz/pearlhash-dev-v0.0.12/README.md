# PearlHash v0.0.12 integer tensor-core correctness component

Independent native sm_120 int8 -> int32 cumulative matrix-product path.
This is an offline component, not a mining search loop or performance result.

The kernel uses dense mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32, packs
signed bytes into documented warp fragments and keeps cumulative integer
accumulators across rank boundaries. Inputs are already-noised selected matrix
rows/columns. Padded rows/columns contribute zero and never write beyond the
logical output. A separate launch folds the transcript and hashes the digest.
Every rank-boundary product, transcript word and digest is compared with an
independent scalar CPU calculation. All output buffers have poison guards.
No saturation, floating-point conversion or FP8 algorithm changes are used.

Compilation with NVRTC 12.9.86 succeeds; own-code disassembly confirms native
IMMA.16832.S8.S8. CPU checks cover signed extremes, one-hot edge tiles, multiple
warps and repeated transcript slots. The new GPU execution is pending.
No hashrate, latency, power improvement or accepted-share claim is made.

Authority for register mapping and instruction semantics:
https://docs.nvidia.com/cuda/parallel-thread-execution/#warp-level-matrix-fragment-mma-16832

Run from this directory, leaving the existing miner running:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/check_mma_gpu.py --fixture /path/to/your/local/PHGPU02-file.bin --report ./mma-result.json

The optional local file can reuse the completed v0.0.11 replay output. No
commitments, captures or official proof checks are repeated. Four synthetic
cases run first. The private fixture is read only; no private data/fingerprints
are bundled, uploaded or written back. No network, clocks, services or autostart
operations. A GPU failure stops the test; there is no scalar GPU fallback.

Matrices are bounded at 32x32 selected outputs, k<=65536 and power-of-two ranks
32..1024. Signed values are bounded to [-127,127] and the total int32 sum cannot
overflow. Local fixtures must use PHGPU02 and fit the 8-MiB parser cap.
A successful run saves a local completion report so completed work need not be repeated.
Per-case device allocations are freed, and only the test's own context is closed.
The unchanged v0.0.11 CPU hash library/source is included for independent digest
checks; no CUDA/Rust/Python-extension installation is needed on the rig.

Rebuild the cubin on a development host:

    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/mma-sm120.cubin mma_correctness.cu

The previously completed captured-share replay passed GPU math and the official
CPU verifier. That remains offline evidence from an existing miner's share,
not a submitted/accepted custom share or a working independent pool miner.

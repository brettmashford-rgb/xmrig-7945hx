# PearlHash v0.0.15 periodic range scheduler

Adds random-access periodic tile planning without enumerating matrix rows or
allocating complete matrices. The observed 10x16 pattern domain at m=5121,
n=262144 has 512 x 16384 = 8388608 tiles. This is a domain count, not completed
mining work. The rig harness checks only six production-domain tiles: two each
at the start, middle and end, using synthetic seeds. It also checks all15 tiles
of a small synthetic domain, including the nonce-derived final A-row tail.

The planner maps global tile IDs into local row/column pools bounded at32 per
side and up to64 queries per batch. Constant signals are constructed only for
selected rows. Noise and exact tile math use the existing GPU pipeline; full
logical signal/noised matrices are never allocated. Bounded signal/noise inputs
remain held across a queue-overflow retry and are freed at the next batch.
This is a correctness baseline, not an efficient full-domain search benchmark.

The dispatcher checks a caller generation before launches/retries and candidate
delivery. A changed generation cancels the unfinished batch without advancing
its cursor. Overflowed partial candidates are discarded; the batch retries with
capacity for all its queries. Cursor advances only after complete validated
results and synchronous callback delivery. The test cancels after one committed
batch, resumes, and verifies every small-domain tile is delivered exactly once.

These are generation hooks and an in-memory resumable cursor, not a live pool
job listener, persistent miner state or externally atomic submission gate. The
caller must bind each generation/cursor to its immutable profile and make its
callback idempotent if it can fail after side effects. Backend/validation/delivery
failure leaves the current batch cursor unadvanced. No pool callbacks are used.

Reuses the unchanged native sm_120 cubin from v0.0.14, already tested on RTX5060
for five batches /200 tile-target-queue cases. No new CUDA compilation was done.
New CPU tests match valid offsets with brute force, check large-domain indexing,
map reconstruction, exact coverage, bounded batching, overflow retry, cancellation,
resume, failed delivery and constant-signal/tail limits. 57 development tests pass,
two prior oracle/vector cases skip. New scheduler-to-GPU integration is pending.

Run with Python3.10+ and NVIDIA driver; no CUDA/Rust/pip install required:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/check_range_scan_gpu.py --report ./range-scan-result.json

The harness uses synthetic supplied seeds, a constant signal profile and maximum
already-scaled bounds to exercise every candidate/overflow path. It compares
all tested tile digests/transcripts with CPU references, so it is not a fast
production worker. It does not derive header-bound seeds, build commitments,
search nonces, scan a complete production range, submit proofs or contact a pool.
General patterns/profile tests do not establish consensus/job compatibility.
No hashrate, power or speed improvement is claimed.

No private capture or replay file is needed for this stage. No network calls,
service/clock/autostart changes or foreign CUDA allocations. Leave the existing
miners running. Completion is saved locally only after every requested window,
retry and cancellation/resume check passes. Existing reports are refused.

Signal profile cap: logical matrices <=8GiB each, k<=65536 and power-of-two
rank32..1024 with divisible k; fill/tail bytes [-64,64]; u32-safe uniform indices.
Those are primitive resource bounds, not the complete consensus sanity rules.
The range ID count fits u64; each actual GPU launch uses only the bounded pools.

GPU rebuild recipe, if needed on the development host (unchanged from v0.0.14):

    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/tile-scan-sm120.cubin tile_scan.cu

CPU library rebuild (included bytes unchanged from v0.0.11):

    g++ -std=c++17 -O3 -shared -fPIC proof/blake3_cpu.cpp -o bin/libpearlhash.so

ISC license. No vendor miner runtime or developer fee. BUILD.json binds sources
and the reused binary with hashes. Real custom pool acceptance remains unproven.

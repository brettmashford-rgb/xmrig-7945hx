# PearlHash v0.0.10 GPU commitment leaves to proof

Synthetic offline integration. Not a pool miner or a benchmark.
Fresh signal matrices -> GPU chunk CVs -> CPU parent folds -> all-node CPU
comparison -> CPU seeds -> GPU noise/products/transcript/digest -> CPU Merkle
openings/PlainProof -> the pinned official CPU verifier.

The commitment kernel and native CPU hash library are unchanged v0.0.9 bytes.
Only the standalone v0.0.9 GPU leaf test has passed on the rig so far. This new
integration's GPU execution and official-verifier run are pending. Development
CPU tests use an explicitly CPU-emulated leaf backend and compare complete proof
bytes against the existing CPU pipeline for both V2 and V3; they are not GPU or
new official-verifier tests.

The default batch is 128 chunks (128 KiB of signal data); all per-batch device
allocations are freed before the next batch. Every GPU leaf and every CPU parent
must match an independent CPU tree before seed derivation. Invalid outputs fail
closed. Single-chunk roots use CPU root-domain hashing. Full tree inputs retain
the existing 64-MiB cap. These are 128x2048 / 128x4096 synthetic matrices, not the
pool's production matrix layout. No pool connection, submitted share, service,
clock or autostart change; no speed or power claim.

From this directory (reuse already installed, previously tested components):

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S -m tools.offline_end_to_end --gpu-commitments --oracle /home/user/pearlhash-dev-v0.0.2/bin/pearl-cpu-oracle --gpu-check /home/user/pearlhash-dev-v0.0.5/bin/pearl-gpu-check --cubin /home/user/pearlhash-dev-v0.0.5/gpu/correctness-sm120.cubin --output-dir ./run

The existing v0.0.2 and v0.0.5 packages remain available through the project's
GitHub. Do not reinstall or repeat their old fixture checks if already present.
This package includes the current independent integration source and unchanged
commitment cubin/hash library; it does not duplicate the old math binary/oracle.
Inspect run/manifest.json after completion for roots, proof hashes and stages.
No complete current-pool reconstruction or accepted custom share exists.

# PearlHash v0.0.14 bounded GPU tile scan

The kernel evaluates several caller-selected tiles over the same GPU-generated
signed matrices. It keeps cumulative int32 products in MMA registers and folds
rank-boundary values with warp shuffles and block barriers. Transcript, keyed
digest and little-endian u256 comparison happen inside that kernel. The normal
result contains only candidate tile IDs, caller generation tags and digests.
It does not copy every prefix product back to the CPU. An optional correctness
audit copies 16 transcript words per tile; no global prefix array is allocated.

Bounds are supplied ALREADY SCALED by the caller. The primitive accepts digest
<= bound, matching the pinned official verifier's integer comparison. It does
not calculate consensus/pool scaling or infer version context. Matrix dimensions,
tile patterns and duplicate slots in synthetic tests are general math cases,
not assertions that they form consensus-valid proofs. Seeds/signals are supplied.
There is no full nonce/job search loop, pool client or submission in this build.

The compact queue atomically counts all hits. Overflow is flagged even when
capacity is zero; records cannot be treated as complete after overflow. Candidate
decode rejects wrong digests, duplicates, unknown tile IDs and stale generation
tags. The driver waits for completion before reading results. Caller generation
tags provide correlation, not an implemented live-job cancellation mechanism.

The test runs four synthetic input batches plus an optional existing local
PHGPU02 file. Each batch uses five tile maps and eight target/queue checks:
all hits with transcript audit, digest-1, equality, digest+1, zero bound, mixed
bounds, one-slot overflow and zero-slot overflow. Candidate order is irrelevant.
CPU references are independent scalar noise and matrix calculations. GPU uniform,
permutation and noised bytes are checked before the same device buffers feed
all scan launches. Output guards cover noise, counter, queue and audit buffers.
No CPU noised matrices are uploaded. No private input or result is uploaded.

The rank32 32x32 synthetic tile exercises eight warps, and rank32 k=1056 reuses
transcript slots. Reversed, padded, one-output and repeated-slot maps are covered.
The saved local replay input can be reused without a capture, commitment rebuild,
proof regeneration or another official verifier invocation.

Compilation succeeds for native sm_120. 53 development CPU tests pass, two prior
oracle/vector tests skip. The actual comparator passes 1144 Python-integer
boundary/random comparisons; candidate/schema tests reject corrupted/stale data
and partial queues. CPU checks do not execute GPU MMA/shuffles/barriers/atomics.
The prior noise-to-MMA GPU component passed on RTX 5060. This new scan's GPU
execution is pending. No hashrate, timing, power or efficiency result is claimed.

Run with Python 3.10+ and the NVIDIA driver, no compiler/Rust/pip installation:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/check_tile_scan_gpu.py --fixture /path/to/local/PHGPU02.bin --report ./tile-scan-result.json

The runner makes no network connections or changes to miners, services, clocks
or autostart. It only owns its own CUDA context/allocations. The existing miners
can remain running. CPU comparisons and debug downloads make this a correctness
harness, not a production performance measurement. A local completion report is
written only after every requested check passes; existing reports are refused.

Bounds: 1..32 pooled rows/columns and 1..32 selected rows/columns per tile,
1..64 tile queries, k<=65536, power-of-two rank32..1024 with k divisible by rank,
signals [-64,64], noised bytes [-127,127], u32-safe noise row indices, u64 generation.
Inputs fit int32 cumulative products. Bound, descriptor and fixture validation
occurs before launch. No CPU fallback is reported as GPU work.

Rebuild cubin on a development host with included sources:

    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/tile-scan-sm120.cubin tile_scan.cu

Rebuild the included unchanged CPU hash library if needed:

    g++ -std=c++17 -O3 -shared -fPIC proof/blake3_cpu.cpp -o bin/libpearlhash.so

Pinned algorithm authority: pearl-research-labs/pearl commit
82e6eee7076aafe10123e08db78f100d270c0582, api/sanity_checks.rs and api/verify.rs.
Warp/CTA synchronization authority: NVIDIA CUDA Programming Guide,
https://docs.nvidia.com/cuda/cuda-c-programming-guide/#warp-shuffle-functions

ISC license. No vendor miner runtime or developer fee. BUILD.json binds sources
with hashes. Full independent mining and real custom pool acceptance remain work.

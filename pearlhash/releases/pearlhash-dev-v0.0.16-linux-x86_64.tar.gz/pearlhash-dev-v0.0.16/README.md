# PearlHash v0.0.16 fresh nonce-to-proof integration

Connects the independently implemented pieces into one fresh synthetic path:
header/config -> job key -> nonce tail -> full constant-matrix commitments ->
explicit V2/V3 seeds -> GPU range candidate -> independent PlainProof -> existing
official CPU verifier. This is still offline development, not a working pool miner.

Previously the range tests supplied arbitrary seeds and maximum bounds. This
runner derives seeds from header/config and nonce-dependent commitments, and
uses a real non-saturating synthetic target. nBits0x1e100000 decodes to2^236;
rank128, tile8x8, k4096 scales to2^254. Equality is accepted. This fixed test
profile is not a general pool target/version/configuration decoder. Synthetic
matrices have m=n=128; the full 256-tile domain is searched only until the first
completed batch with a candidate. At most three fresh synthetic nonces per
explicit V2/V3 context are attempted. No production range completion is claimed.

CPU work: synthetic job/header, nonce-to-tail mapping, streamed full A/B roots,
explicit dense seed derivation, scalar noise/math references and proof encoding.
The B commitment is cached by job key, including across same-job nonce attempts.
The A commitment changes with the nonce tail. Selected rows/columns and candidate
IDs come from the periodic range planner. GPU work uses the unchanged validated
noise/tensor-core scanner with the actual scaled bound; queue overflow retries
complete before a candidate is chosen. All tested GPU digests/transcripts are
compared with scalar CPU references, so this is not a fast production worker.

Before proof construction, generation, nonce-tail, selected math, target,
commitment-root, seed and pattern bindings are checked. Streamed Merkle openings
are constructed independently and round-trip through the PlainProof parser.
The existing official CPU oracle checks each newly generated V2/V3 proof using
the synthetic header's actual nBits (no target override). A completion manifest
is written only after every requested positive verification succeeds. CPU-only
mode explicitly marks GPU unchecked and official verification not run unless
an oracle was supplied. No private captured header/nonce/proof is bundled/read.

Development checks: 60 CPU tests pass, two prior oracle/vector cases skip. New
roots and selected proof encodings match separate full materialized CPU trees;
nonce changes affect A roots/seeds, V3 salt context differs, stale/cache/target
bindings reject, and actual non-maximal bound filtering/overflow retry pass.
CPU preparation produces target-meeting V2/V3 proofs. New combined GPU and
official CPU verification remain pending on the rig: there is no development-
host Rust compiler or oracle executable. No such verification is claimed yet.

No new native compilation. The package reuses the exact v0.0.14 sm_120 cubin and
v0.0.11 CPU library. v0.0.15 scheduler hardware checks passed on RTX5060. The rig
needs only its existing NVIDIA driver, Python and existing official CPU oracle;
no CUDA/Rust/pip installation or old fixture download/test is needed.

Run from the extracted package, using the existing oracle path:

    PEARL_HASH_LIBRARY="$PWD/bin/libpearlhash.so" python3 -S tools/offline_nonce_search.py --oracle /home/user/pearlhash-dev-v0.0.2/bin/pearl-cpu-oracle --output-dir ./run

The run directory must not exist. A fresh synthetic seed is generated each run;
--seed optionally accepts64 hex digits for development reproduction. Local
proof JSON files and completion manifest are generated; nothing is uploaded.
The source makes no pool connection or service/clock/autostart changes. Existing
WildRig/XMRig can remain running. The selected synthetic job is not a pool job;
no share has been submitted and no pool acceptance or speed/power gain is claimed.

Pinned verification/seed/target authority:
https://github.com/pearl-research-labs/pearl/tree/82e6eee7076aafe10123e08db78f100d270c0582/zk-pow/src/api

GPU rebuild recipe (development host only, unchanged source):

    python3 tools/compile_correctness.py /path/to/libnvrtc.so.12 gpu/tile-scan-sm120.cubin tile_scan.cu

CPU hash library rebuild, if needed:

    g++ -std=c++17 -O3 -shared -fPIC proof/blake3_cpu.cpp -o bin/libpearlhash.so

ISC license; no vendor miner runtime or developer fee. BUILD.json binds included
sources with hashes. Full efficient production search and live pool integration
remain work; no autostart replacement is performed.

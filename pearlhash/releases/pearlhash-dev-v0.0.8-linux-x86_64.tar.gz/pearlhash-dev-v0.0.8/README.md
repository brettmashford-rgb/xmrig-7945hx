# v0.0.8 nonce-tail GPU correctness component

Independent Linux x86_64 test executable, CPU hash library, native sm_120
nonce-tail cubin, Python runner and complete component source. ISC licensed.
This remains a development component, not a pool-working miner.

The isolated client arithmetic is unkeyed BLAKE3(worker_bytes || miner_bytes),
using eight bytes per input, then mapping each of its first sixteen digest bytes
as (byte % 129) - 64 and preserving the resulting signed-byte representation.
Wire fields are preserved as decoded bytes. Full wire-to-kernel/matrix layout
and accepted-job association still require validation; the complete replay of
the captured accepted share has not met its target. Do not treat this primitive
as a validated submission generator or change the Pearl consensus algorithm.

Validation before shipping: 32 synthetic cases match private arithmetic tracing
of inspected client device code (no vendor GPU execution); three synthetic
trace goldens are included. Independent GPU-source kernel-body CPU evaluation
matches the separate native CPU BLAKE3 implementation on 263 cases, including
u32/u64 boundaries and output guards. 25 protocol/nonce CPU tests pass. Native
sm_120 compilation succeeds with NVRTC 12.9.86. No new GPU execution, custom
pool share or speed/power gain is claimed until the rig runs it.

Run the new GPU test (leave existing miners running):

    python3 -S tools/check_nonce_gpu.py

It loads only this cubin through the installed NVIDIA driver's CUDA API and
uses a small private allocation. It checks every output against separate CPU
hashing and verifies both output guards. No CUDA/Rust/Python package installation,
network connection, service restart, clock operation or WildRig runtime dependency.
The old GPU math kernel and its prior completed rig checks are unchanged.

CPU-only tests, already completed on the development host:

    bin/pearl-nonce-cpu-check tests/nonce-tail.bin
    PYTHONPATH=.:tests python3 -S -m unittest test_pool_nonce

Rebuild on a development host with GCC/NVRTC:

    g++ -std=c++17 -O3 -Wall -Wextra -Werror tests/nonce_kernel_cpu.cpp -o bin/pearl-nonce-cpu-check
    g++ -std=c++17 -O3 -Wall -Wextra -Werror -shared -fPIC -fvisibility=hidden proof/blake3_cpu.cpp -o bin/libpearlhash.so
    python3 tools/compile_correctness.py LIBNVRTC gpu/nonce-tail-sm120.cubin nonce_tail.cu

The CPU hash library is unchanged from the previously validated v0.0.5 build.
SHA256SUMS covers all package files except itself. No private session, vendor
binary, arithmetic tracing harness or development toolchain is redistributed.
